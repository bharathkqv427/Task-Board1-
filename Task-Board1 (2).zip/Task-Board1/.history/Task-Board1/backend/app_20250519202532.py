import json
import sqlite3
import uuid
from datetime import datetime
from flask import Flask, request, jsonify, g
from flask_cors import CORS
import config

app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": config.CORS_ORIGINS}})

# Database setup
def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(config.DATABASE)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(e=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()

def init_db():
    with app.app_context():
        db = get_db()
        try:
            # Create tasks table if it doesn't exist
            db.execute('''
                CREATE TABLE IF NOT EXISTS tasks (
                    id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    description TEXT,
                    status TEXT NOT NULL,
                    priority TEXT,
                    due_date TEXT,
                    created_at TEXT,
                    updated_at TEXT
                )
            ''')
            db.commit()
            
            # Check if we need to insert sample data
            cursor = db.execute('SELECT COUNT(*) as count FROM tasks')
            count = cursor.fetchone()['count']
            if count == 0:
                # Insert some sample tasks
                sample_tasks = [
                    {
                        'id': str(uuid.uuid4()),
                        'title': 'Complete project documentation',
                        'description': 'Write comprehensive documentation covering setup and usage instructions.',
                        'status': 'To Do',
                        'priority': 'High',
                        'due_date': (datetime.now().date().isoformat()),
                        'created_at': datetime.now().isoformat(),
                        'updated_at': datetime.now().isoformat()
                    },
                    {
                        'id': str(uuid.uuid4()),
                        'title': 'Design landing page',
                        'description': 'Create UI mockups for the new product landing page.',
                        'status': 'In Progress',
                        'priority': 'Medium',
                        'due_date': (datetime.now().date().isoformat()),
                        'created_at': datetime.now().isoformat(),
                        'updated_at': datetime.now().isoformat()
                    },
                    {
                        'id': str(uuid.uuid4()),
                        'title': 'Fix navigation bug',
                        'description': 'Fix the bug where mobile navigation menu doesn\'t close properly.',
                        'status': 'Done',
                        'priority': 'Low',
                        'created_at': datetime.now().isoformat(),
                        'updated_at': datetime.now().isoformat()
                    }
                ]
                
                for task in sample_tasks:
                    db.execute('''
                        INSERT INTO tasks (id, title, description, status, priority, due_date, created_at, updated_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (
                        task['id'],
                        task['title'],
                        task['description'],
                        task['status'],
                        task['priority'],
                        task.get('due_date'),
                        task['created_at'],
                        task['updated_at']
                    ))
                db.commit()
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            db.rollback()

# Initialize database
init_db()

# Helper functions
def dict_from_row(row):
    return {key: row[key] for key in row.keys()}

# API Routes
@app.route('/api/tasks', methods=['GET'])
def get_tasks():
    try:
        db = get_db()
        cursor = db.execute('SELECT * FROM tasks ORDER BY created_at DESC')
        tasks = [dict_from_row(row) for row in cursor.fetchall()]
        return jsonify(tasks)
    except sqlite3.Error as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/tasks', methods=['POST'])
def create_task():
    try:
        if not request.json or not 'title' in request.json:
            return jsonify({'error': 'Title is required'}), 400
        
        task_data = request.json
        task_id = str(uuid.uuid4())
        now = datetime.now().isoformat()
        
        db = get_db()
        db.execute('''
            INSERT INTO tasks (id, title, description, status, priority, due_date, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            task_id,
            task_data['title'],
            task_data.get('description', ''),
            task_data.get('status', 'To Do'),
            task_data.get('priority', 'Medium'),
            task_data.get('due_date'),
            now,
            now
        ))
        db.commit()
        
        # Return the newly created task
        cursor = db.execute('SELECT * FROM tasks WHERE id = ?', (task_id,))
        task = dict_from_row(cursor.fetchone())
        return jsonify(task), 201
    except sqlite3.Error as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/tasks/<task_id>', methods=['GET'])
def get_task(task_id):
    try:
        db = get_db()
        cursor = db.execute('SELECT * FROM tasks WHERE id = ?', (task_id,))
        task = cursor.fetchone()
        
        if task is None:
            return jsonify({'error': 'Task not found'}), 404
        
        return jsonify(dict_from_row(task))
    except sqlite3.Error as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/tasks/<task_id>', methods=['PUT'])
def update_task(task_id):
    try:
        if not request.json:
            return jsonify({'error': 'No data provided'}), 400
        
        task_data = request.json
        now = datetime.now().isoformat()
        
        db = get_db()
        # Check if task exists
        cursor = db.execute('SELECT * FROM tasks WHERE id = ?', (task_id,))
        task = cursor.fetchone()
        
        if task is None:
            return jsonify({'error': 'Task not found'}), 404
        
        # Update task
        db.execute('''
            UPDATE tasks
            SET title = ?, description = ?, status = ?, priority = ?, due_date = ?, updated_at = ?
            WHERE id = ?
        ''', (
            task_data.get('title', task['title']),
            task_data.get('description', task['description']),
            task_data.get('status', task['status']),
            task_data.get('priority', task['priority']),
            task_data.get('due_date', task['due_date']),
            now,
            task_id
        ))
        db.commit()
        
        # Return the updated task
        cursor = db.execute('SELECT * FROM tasks WHERE id = ?', (task_id,))
        updated_task = dict_from_row(cursor.fetchone())
        return jsonify(updated_task)
    except sqlite3.Error as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/tasks/<task_id>', methods=['DELETE'])
def delete_task(task_id):
    try:
        db = get_db()
        # Check if task exists
        cursor = db.execute('SELECT * FROM tasks WHERE id = ?', (task_id,))
        task = cursor.fetchone()
        
        if task is None:
            return jsonify({'error': 'Task not found'}), 404
        
        # Delete task
        db.execute('DELETE FROM tasks WHERE id = ?', (task_id,))
        db.commit()
        
        return jsonify({'message': 'Task deleted successfully'})
    except sqlite3.Error as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({'status': 'ok', 'version': '1.0.0'})


if __name__ == '__main__':
    app.run(host=config.HOST, port=config.PORT, debug=config.DEBUG)