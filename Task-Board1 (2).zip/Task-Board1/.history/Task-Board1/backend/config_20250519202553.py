
import os
from dotenv import load_dotenv

load_dotenv()

# Environment settings
DEBUG = os.getenv('DEBUG', 'True').lower() in ('true', '1', 't')
HOST = os.getenv('HOST', '0.0.0.0')
PORT = int(os.getenv('PORT', 5000))

# Database settings
DATABASE = os.path.join(os.path.dirname(__file__), 'taskflow.db')

# CORS settings
CORS_ORIGINS = os.getenv('CORS_ORIGINS', '*')