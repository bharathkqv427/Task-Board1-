/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'primary': '#3368EF',
        'primary-dark': '#2652D4',
        'secondary': '#6C8EFA',
        'tertiary': '#A4BDFF',
        'light-bg': '#F7FAFF',
        'card-bg': '#FFFFFF',
        'dark-text': '#233059',
        'light-text': '#6B7280',
        'danger': '#EF4444',
        'success': '#10B981',
        'warning': '#F59E0B',
      },
      boxShadow: {
        'card': '0 2px 10px rgba(51, 104, 239, 0.1)',
        'card-hover': '0 4px 12px rgba(51, 104, 239, 0.15)',
        'button': '0 2px 5px rgba(51, 104, 239, 0.2)',
      },
      borderRadius: {
        'card': '0.5rem',
      },
      animation: {
        'bounce-slow': 'bounce 3s infinite',
      }
    },
  },
  plugins: [],
}
