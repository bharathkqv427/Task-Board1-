import { useState, useEffect } from 'react';
import axios from 'axios';
import toast from 'react-hot-toast';

// Custom hook to manage the task board state and operations
export default function useTaskBoard() {
  const [columns, setColumns] = useState({
    'todo': {
      id: 'todo',
      title: 'To Do',
      taskIds: [],
      color: 'bg-blue-100 border-blue-300'
    },
    'inprogress': {
      id: 'inprogress',
      title: 'In Progress',
      taskIds: [],
      color: 'bg-amber-100 border-amber-300'
    },
    'done': {
      id: 'done',
      title: 'Done',
      taskIds: [],
      color: 'bg-green-100 border-green-300'
    }
  });
  
  const [tasks, setTasks] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch all tasks from the backend
  const fetchTasks = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/api/tasks');
      
      const newTasks = {};
      const newColumns = {
        'todo': { ...columns.todo, taskIds: [] },
        'inprogress': { ...columns.inprogress, taskIds: [] },
        'done': { ...columns.done, taskIds: [] }
      };
      
      // Process tasks and organize by column
      response.data.forEach(task => {
        newTasks[task.id] = task;
        const columnId = task.status.toLowerCase().replace(' ', '');
        if (newColumns[columnId]) {
          newColumns[columnId].taskIds.push(task.id);
        }
      });
      
      setTasks(newTasks);
      setColumns(newColumns);
      setLoading(false);
    } catch (err) {
      console.error('Error fetching tasks:', err);
      setError('Failed to load tasks. Please try again later.');
      setLoading(false);
      toast.error('Failed to load tasks');
    }
  };

  // Create a new task
  const createTask = async (taskData) => {
    try {
      const response = await axios.post('/api/tasks', taskData);
      const newTask = response.data;
      
      // Update state with new task
      setTasks(prev => ({
        ...prev,
        [newTask.id]: newTask
      }));
      
      // Add task id to appropriate column
      setColumns(prev => {
        const columnId = newTask.status.toLowerCase().replace(' ', '');
        return {
          ...prev,
          [columnId]: {
            ...prev[columnId],
            taskIds: [...prev[columnId].taskIds, newTask.id]
          }
        };
      });
      
      toast.success('Task created successfully');
      return newTask;
    } catch (err) {
      console.error('Error creating task:', err);
      toast.error('Failed to create task');
      throw err;
    }
  };

  // Update an existing task
  const updateTask = async (taskId, updatedData) => {
    try {
      const response = await axios.put(`/api/tasks/${taskId}`, updatedData);
      const updatedTask = response.data;
      
      // Find old column and new column
      const oldTask = tasks[taskId];
      const oldColumnId = oldTask.status.toLowerCase().replace(' ', '');
      const newColumnId = updatedTask.status.toLowerCase().replace(' ', '');
      
      // Update tasks state
      setTasks(prev => ({
        ...prev,
        [taskId]: updatedTask
      }));
      
      // If status changed, update columns
      if (oldColumnId !== newColumnId) {
        setColumns(prev => {
          // Remove from old column
          const oldTaskIds = prev[oldColumnId].taskIds.filter(id => id !== taskId);
          
          // Add to new column
          const newTaskIds = [...prev[newColumnId].taskIds, taskId];
          
          return {
            ...prev,
            [oldColumnId]: {
              ...prev[oldColumnId],
              taskIds: oldTaskIds
            },
            [newColumnId]: {
              ...prev[newColumnId],
              taskIds: newTaskIds
            }
          };
        });
      }
      
      toast.success('Task updated successfully');
      return updatedTask;
    } catch (err) {
      console.error('Error updating task:', err);
      toast.error('Failed to update task');
      throw err;
    }
  };

  // Delete a task
  const deleteTask = async (taskId) => {
    try {
      await axios.delete(`/api/tasks/${taskId}`);
      
      // Get the column this task belongs to
      const taskToDelete = tasks[taskId];
      const columnId = taskToDelete.status.toLowerCase().replace(' ', '');
      
      // Remove task from tasks state
      setTasks(prev => {
        const newTasks = { ...prev };
        delete newTasks[taskId];
        return newTasks;
      });
      
      // Remove task from column
      setColumns(prev => {
        return {
          ...prev,
          [columnId]: {
            ...prev[columnId],
            taskIds: prev[columnId].taskIds.filter(id => id !== taskId)
          }
        };
      });
      
      toast.success('Task deleted successfully');
    } catch (err) {
      console.error('Error deleting task:', err);
      toast.error('Failed to delete task');
      throw err;
    }
  };

  // Handle drag and drop between columns
  const moveTask = async (taskId, sourceColumn, destinationColumn) => {
    try {
      // Update the task status to match the new column
      const columnToStatusMap = {
        'todo': 'To Do',
        'inprogress': 'In Progress',
        'done': 'Done'
      };
      
      // Update in the backend
      const taskToUpdate = tasks[taskId];
      await updateTask(taskId, {
        ...taskToUpdate,
        status: columnToStatusMap[destinationColumn]
      });
      
      toast.success(`Task moved to ${columnToStatusMap[destinationColumn]}`);
    } catch (err) {
      console.error('Error moving task:', err);
      toast.error('Failed to move task');
      
      // Revert the UI state if the backend update fails
      fetchTasks();
    }
  };

  // Handle drag end (for react-beautiful-dnd)
  const handleDragEnd = async (result) => {
    const { destination, source, draggableId } = result;
    
    // If there's no destination or if dropped in the same place
    if (!destination || 
       (destination.droppableId === source.droppableId && 
        destination.index === source.index)) {
      return;
    }
    
    // Reorder within the same column
    if (destination.droppableId === source.droppableId) {
      const column = columns[source.droppableId];
      const newTaskIds = Array.from(column.taskIds);
      
      // Remove from previous position and insert into new position
      newTaskIds.splice(source.index, 1);
      newTaskIds.splice(destination.index, 0, draggableId);
      
      // Update state with new order
      setColumns({
        ...columns,
        [source.droppableId]: {
          ...column,
          taskIds: newTaskIds
        }
      });
    } 
    // Move between columns
    else {
      const sourceColumn = columns[source.droppableId];
      const destColumn = columns[destination.droppableId];
      
      // Remove from source column
      const sourceTaskIds = Array.from(sourceColumn.taskIds);
      sourceTaskIds.splice(source.index, 1);
      
      // Add to destination column
      const destTaskIds = Array.from(destColumn.taskIds);
      destTaskIds.splice(destination.index, 0, draggableId);
      
      // Update column state
      setColumns({
        ...columns,
        [source.droppableId]: {
          ...sourceColumn,
          taskIds: sourceTaskIds
        },
        [destination.droppableId]: {
          ...destColumn,
          taskIds: destTaskIds
        }
      });
      
      // Update task status in backend
      await moveTask(draggableId, source.droppableId, destination.droppableId);
    }
  };

  // Load tasks on initial mount
  useEffect(() => {
    fetchTasks();
  }, []);

  return {
    columns,
    tasks,
    loading,
    error,
    createTask,
    updateTask,
    deleteTask,
    handleDragEnd,
    refreshTasks: fetchTasks
  };
}