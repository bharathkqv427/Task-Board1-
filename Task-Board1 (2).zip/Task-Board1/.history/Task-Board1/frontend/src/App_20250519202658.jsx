import { useState } from 'react';
import { DragDropContext } from 'react-beautiful-dnd';
import { motion } from 'framer-motion';
import Board from './components/Board';
import Navbar from './components/Navbar';
import TaskForm from './components/TaskForm';
import useTaskBoard from './hooks/useTaskBoard';

function App() {
  const {
    columns,
    tasks,
    loading,
    error,
    createTask,
    updateTask,
    deleteTask,
    handleDragEnd,
    refreshTasks
  } = useTaskBoard();

  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState(null);

  const handleOpenCreateModal = () => {
    setIsCreateModalOpen(true);
    setEditingTask(null);
  };

  const handleCloseModal = () => {
    setIsCreateModalOpen(false);
    setEditingTask(null);
  };

  const handleEditTask = (task) => {
    setEditingTask(task);
    setIsCreateModalOpen(true);
  };

  const handleSubmitTask = async (taskData) => {
    try {
      if (editingTask) {
        await updateTask(editingTask.id, taskData);
      } else {
        await createTask(taskData);
      }
      handleCloseModal();
    } catch (err) {
      console.error('Error submitting task:', err);
    }
  };


  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        duration: 0.5,
        when: 'beforeChildren',
        staggerChildren: 0.1
      }
    }
  };

  return (
    <div className="min-h-screen bg-light-bg flex flex-col">
      <Navbar onCreateTask={handleOpenCreateModal} />
      
      <motion.main 
        className="flex-1 container mx-auto px-4 py-6"
        initial="hidden"
        animate="visible"
        variants={containerVariants}
      >
        <DragDropContext onDragEnd={handleDragEnd}>
          <Board 
            columns={columns} 
            tasks={tasks}
            loading={loading}
            error={error}
            onEditTask={handleEditTask}
            onDeleteTask={deleteTask}
          />
        </DragDropContext>
      </motion.main>

      {/* Task Creation/Edit Modal */}
      {isCreateModalOpen && (
        <TaskForm
          task={editingTask}
          onClose={handleCloseModal}
          onSubmit={handleSubmitTask}
        />
      )}
    </div>
  );
}

export default App;