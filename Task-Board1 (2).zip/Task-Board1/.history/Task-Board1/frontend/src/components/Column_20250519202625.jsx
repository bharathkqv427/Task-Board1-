import { Droppable } from 'react-beautiful-dnd';
import { motion } from 'framer-motion';
import TaskCard from './TaskCard';

const Column = ({ column, tasks, onEditTask, onDeleteTask }) => {

  const columnVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        type: 'spring',
        stiffness: 100,
        mass: 0.8,
        when: 'beforeChildren',
        staggerChildren: 0.1
      }
    }
  };


  const getColumnColor = () => {
    const colors = {
      'todo': 'bg-blue-50 border-l-4 border-blue-400',
      'inprogress': 'bg-amber-50 border-l-4 border-amber-400',
      'done': 'bg-green-50 border-l-4 border-green-400'
    };
    return colors[column.id] || 'bg-gray-50 border-l-4 border-gray-400';
  };

  // Get column icon based on status
  const getColumnIcon = () => {
    const icons = {
      'todo': '📋',
      'inprogress': '⚙️',
      'done': '✅'
    };
    return icons[column.id] || '📄';
  };

  return (
    <motion.div 
      className={`${getColumnColor()} rounded-xl shadow-md overflow-hidden flex flex-col`}
      variants={columnVariants}
    >
      <div className="p-4 bg-white bg-opacity-90 border-b border-gray-200">
        <div className="flex items-center">
          <span className="text-xl mr-2">{getColumnIcon()}</span>
          <h2 className="text-lg font-semibold text-dark-text">{column.title}</h2>
          <div className="ml-2 px-2 py-1 bg-gray-100 rounded-full text-xs font-medium text-gray-600">
            {tasks.length}
          </div>
        </div>
      </div>
      
      <Droppable droppableId={column.id}>
        {(provided, snapshot) => (
          <div
            ref={provided.innerRef}
            {...provided.droppableProps}
            className={`flex-1 p-3 min-h-[300px] overflow-y-auto transition-colors duration-200 ${
              snapshot.isDraggingOver ? 'bg-blue-50 bg-opacity-70' : ''
            }`}
          >
            {tasks.length === 0 && !snapshot.isDraggingOver && (
              <div className="h-full flex items-center justify-center">
                <p className="text-light-text text-center p-4 italic">
                  No tasks yet. Drag tasks here or create a new one.
                </p>
              </div>
            )}

            {tasks.map((task, index) => (
              <TaskCard
                key={task.id}
                task={task}
                index={index}
                onEdit={() => onEditTask(task)}
                onDelete={() => onDeleteTask(task.id)}
              />
            ))}
            {provided.placeholder}
          </div>
        )}
      </Droppable>
    </motion.div>
  );
};

export default Column;