import { motion } from 'framer-motion';
import Column from './Column';

const Board = ({ columns, tasks, loading, error, onEditTask, onDeleteTask }) => {
  // Animation variants
  const boardVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15
      }
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="flex flex-col items-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mb-4"></div>
          <p className="text-lg text-light-text">Loading your tasks...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="bg-red-50 p-6 rounded-lg border border-red-200 max-w-md">
          <h3 className="text-lg font-medium text-red-800 mb-2">There was a problem</h3>
          <p className="text-red-600">{error}</p>
          <button 
            className="mt-4 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
            onClick={() => window.location.reload()}
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <motion.div 
      className="grid grid-cols-1 md:grid-cols-3 gap-6 h-full"
      variants={boardVariants}
      initial="hidden"
      animate="visible"
    >
      {Object.values(columns).map((column) => (
        <Column
          key={column.id}
          column={column}
          tasks={column.taskIds.map(taskId => tasks[taskId])}
          onEditTask={onEditTask}
          onDeleteTask={onDeleteTask}
        />
      ))}
    </motion.div>
  );
};

export default Board;