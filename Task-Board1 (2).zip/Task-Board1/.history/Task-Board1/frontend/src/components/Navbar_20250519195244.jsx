import { motion } from 'framer-motion';
import { FaPlus } from 'react-icons/fa';

const Navbar = ({ onCreateTask }) => {
  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <motion.div 
          className="flex items-center"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex items-center mr-2">
            <div className="w-8 h-8 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center">
              <motion.span 
                className="text-white font-bold"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.3, type: 'spring', stiffness: 200 }}
              >
                TF
              </motion.span>
            </div>
          </div>
          <h1 className="text-xl font-bold text-dark-text">
            <span className="text-primary">Task</span>Flow
          </h1>
        </motion.div>
        
        <div className="flex items-center">
          <motion.button
            className="btn btn-primary flex items-center gap-2"
            onClick={onCreateTask}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <FaPlus size={14} />
            <span>New Task</span>
          </motion.button>
        </div>
      </div>
    </header>
  );
};

export default Navbar;