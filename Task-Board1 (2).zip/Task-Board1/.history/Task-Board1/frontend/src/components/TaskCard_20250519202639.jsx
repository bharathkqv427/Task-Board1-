import { Draggable } from 'react-beautiful-dnd';
import { motion } from 'framer-motion';
import { FaEdit, FaTrashAlt } from 'react-icons/fa';
import { useState } from 'react';

const TaskCard = ({ task, index, onEdit, onDelete }) => {
  const [isHovered, setIsHovered] = useState(false);
  

  const formatDate = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  };


  const getPriorityColor = (priority) => {
    const colors = {
      'High': 'bg-red-100 text-red-800',
      'Medium': 'bg-amber-100 text-amber-800',
      'Low': 'bg-green-100 text-green-800'
    };
    return colors[priority] || 'bg-gray-100 text-gray-800';
  };

  // Variants for animations
  const cardVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { 
        type: 'spring',
        stiffness: 100
      }
    },
    exit: { 
      opacity: 0,
      scale: 0.8,
      transition: { duration: 0.2 }
    }
  };

  const handleDelete = (e) => {
    e.stopPropagation();
    onDelete();
  };

  return (
    <Draggable draggableId={task.id.toString()} index={index}>
      {(provided, snapshot) => (
        <motion.div
          ref={provided.innerRef}
          {...provided.draggableProps}
          {...provided.dragHandleProps}
          variants={cardVariants}
          className={`card card-hover mb-3 ${snapshot.isDragging ? 'task-dragging shadow-lg ring-2 ring-primary ring-opacity-50' : ''}`}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
          style={{
            ...provided.draggableProps.style,
          }}
        >
          <div className="flex justify-between items-start">
            <h3 className="font-medium text-dark-text truncate">{task.title}</h3>
            
            {/* Action buttons - show on hover */}
            <motion.div 
              className="flex space-x-2"
              initial={{ opacity: 0 }}
              animate={{ opacity: isHovered ? 1 : 0 }}
              transition={{ duration: 0.2 }}
            >
              <button 
                onClick={onEdit}
                className="p-1 text-blue-600 hover:bg-blue-100 rounded-full transition-colors"
                title="Edit task"
              >
                <FaEdit size={14} />
              </button>
              <button 
                onClick={handleDelete}
                className="p-1 text-red-600 hover:bg-red-100 rounded-full transition-colors"
                title="Delete task"
              >
                <FaTrashAlt size={14} />
              </button>
            </motion.div>
          </div>
          
          {/* Task description */}
          {task.description && (
            <p className="text-sm text-light-text mt-2 line-clamp-2">{task.description}</p>
          )}
          
          {/* Task metadata */}
          <div className="mt-3 pt-2 border-t border-gray-100 flex justify-between">
            {task.priority && (
              <span className={`inline-block px-2 py-1 text-xs font-medium rounded-full ${getPriorityColor(task.priority)}`}>
                {task.priority}
              </span>
            )}
            
            {task.due_date && (
              <span className="text-xs text-light-text" title="Due date">
                {formatDate(task.due_date)}
              </span>
            )}
          </div>
        </motion.div>
      )}
    </Draggable>
  );
};

export default TaskCard;